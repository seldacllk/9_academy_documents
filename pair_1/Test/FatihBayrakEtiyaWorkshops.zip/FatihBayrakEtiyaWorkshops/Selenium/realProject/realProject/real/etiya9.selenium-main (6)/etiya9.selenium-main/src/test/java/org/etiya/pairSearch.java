package org.etiya;
import junit.framework.Assert;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.SoftAssertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class pairSearch {

  ChromeDriver chromeDriver;
  WebDriverWait wait;
  SoftAssertions softAssertions;
  String testName;

  @BeforeEach
  public void setup() {

    chromeDriver = new ChromeDriver();
    wait = new WebDriverWait(chromeDriver, Duration.ofSeconds(20));
    chromeDriver.manage().window().maximize();
    softAssertions = new SoftAssertions();

  }

  @AfterEach
  public void cleanup() throws InterruptedException {
    takeScreenshotAfterTest();
    Thread.sleep(5000);
    chromeDriver.quit();
  }

  private void takeScreenshotAfterTest() {
    File screenshot = chromeDriver.getScreenshotAs(OutputType.FILE);
    String currentDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
    String folderPath = "C:\\Users\\fatih.bayrak\\Desktop\\Intellij_codes\\test_ss_project\\" + currentDate;
    String filePath = folderPath + "\\" + testName + ".png";

    try {
      File directory = new File(folderPath);
      if (!directory.exists()) {
        directory.mkdirs();
      }

      FileUtils.copyFile(screenshot, new File(filePath));
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("Can not take ScreenShot");
    }
  }

  @Test
  public void testLoginWithCorrectCredentials() throws InterruptedException {
    testName = "testLoginWithCorrectCredentials";
    chromeDriver.get(configProperties.loginUrl);
    try{
      WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
      softAssertions
              .assertThat(usernameInput.isDisplayed())
              .as("Username entry not found.");
      usernameInput.sendKeys(configProperties.usermail);

      WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
      softAssertions.
              assertThat(passwordInput.isDisplayed())
              .as("Password entry not found.");
      passwordInput.sendKeys(configProperties.passwmail);

      WebElement loginBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-button")));
      softAssertions
              .assertThat(loginBtn.isDisplayed())
              .as("Login button not found.");
      loginBtn.click();

      Thread.sleep(3000);

      String actualResult = chromeDriver.getCurrentUrl();
      String expectedRes = configProperties.BaseUrl;
      assertEquals(expectedRes,actualResult,"The url redirected after login is incorrect.");

    }
    finally {
      softAssertions.assertAll();
    }
  }

  @Test // FR2 - TC1
  public void checkExistCustomerSearchBlanks() throws InterruptedException {

    testLoginWithCorrectCredentials();


    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-search")));
    softAssertions
            .assertThat(searchInput.isDisplayed())
            .as("Could not find Search Button.");
    searchInput.click();


    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));

    softAssertions
            .assertThat(natID.isDisplayed())
            .as("Could not find field of Nat ID.");

  }

  @Test // FR2 - TC2
  public void checkCreateCustomerButton() throws InterruptedException {

    testLoginWithCorrectCredentials();

    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";

    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("Could not find Create Customer Button.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer button working wrongly..");

  }

  @Test // FR2 - TC3
  public void checkClearButtonWorks() throws InterruptedException {

    testLoginWithCorrectCredentials();

    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));
    softAssertions
            .assertThat(natID.isDisplayed())
            .as("Could not find field of NatID.");
    natID.click();
    natID.sendKeys("1");

    WebElement search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search-button")));
    softAssertions
            .assertThat(search.isDisplayed())
            .as("Could not find Search Button.");
    search.click();

    Thread.sleep(3000);

    WebElement clearButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("clear-button")));
    softAssertions
            .assertThat(clearButton.isDisplayed())
            .as("Could not find Clear Button.");
    //clearButton.click();

    List<WebElement> searchResults = chromeDriver.findElements(By.cssSelector("body > app-root > app-main-layout > app-search-customer > div.relative.overflow-x-auto.sm\\:rounded-lg.max-w-7xl.mx-auto.p-6 > table"));

    Assert.assertTrue("Result of Search did not cleaned up!", searchResults.isEmpty());



  }

  @Test // FR2 - TC4
  public void verifyInactiveSearchButton() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

  @Test // FR2 - TC5
  public void isBlanksWorksTogether() throws InterruptedException {

    testLoginWithCorrectCredentials();


    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-search")));
    softAssertions
            .assertThat(searchInput.isDisplayed())
            .as("search butonu bulunamadı.");
    searchInput.click();


    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));

    softAssertions
            .assertThat(natID.isDisplayed())
            .as("nat ID boşluğu bulunamadı.");




  }

  @Test // FR2 - TC6
  public void isCustomerInfoRegistered() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

  @Test // FR2 - TC7
  public void isSelectedCustomerInfo() throws InterruptedException {

    testLoginWithCorrectCredentials();


    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-search")));
    softAssertions
            .assertThat(searchInput.isDisplayed())
            .as("search butonu bulunamadı.");
    searchInput.click();


    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));

    softAssertions
            .assertThat(natID.isDisplayed())
            .as("nat ID boşluğu bulunamadı.");




  }

  @Test // FR2 - TC8
  public void isUserCannotFind() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

  @Test // FR2 - TC9
  public void isShowingObligatoryFields() throws InterruptedException {

    testLoginWithCorrectCredentials();


    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-search")));
    softAssertions
            .assertThat(searchInput.isDisplayed())
            .as("search butonu bulunamadı.");
    searchInput.click();


    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));

    softAssertions
            .assertThat(natID.isDisplayed())
            .as("nat ID boşluğu bulunamadı.");




  }

  @Test // FR2 - TC10
  public void isArrangeResultCustomers() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

  @Test // FR2 - TC11
  public void atLeastFiveCustomerInfo() throws InterruptedException {

    testLoginWithCorrectCredentials();


    WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-search")));
    softAssertions
            .assertThat(searchInput.isDisplayed())
            .as("search butonu bulunamadı.");
    searchInput.click();


    WebElement natID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("natID")));

    softAssertions
            .assertThat(natID.isDisplayed())
            .as("nat ID boşluğu bulunamadı.");




  }

  @Test // FR2 - TC12
  public void resultShouldBeUptoEleven() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

  @Test // FR2 - TC13
  public void resultShouldBeAppear() throws InterruptedException {

    testLoginWithCorrectCredentials();
    String expectedUrl = "http://localhost:4200/customer/create-customer/customer-info";


    WebElement CreateCustomerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("create-customer")));
    softAssertions
            .assertThat(CreateCustomerButton.isDisplayed())
            .as("search butonu bulunamadı.");
    CreateCustomerButton.click();

    String actualResult = chromeDriver.getCurrentUrl();

    assertEquals(expectedUrl,actualResult,"Create customer butonu hatalı çalışıyor..");

  }

}

