package org.etiya;

import org.openqa.selenium.chrome.ChromeDriver;

public class configProperties {

    public static String usermail = "test@test.com";
    public static String passwmail = "test";
    public static String loginUrl = "http://localhost:4200/user/login";
    public static String BaseUrl = "http://localhost:4200/customer/search-customer";




}
