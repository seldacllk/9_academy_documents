import java.util.HashMap;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        String word = "3kere";
        HashMap<Character,Integer> hashMap = new HashMap<>();

        for(int i = 0 ; i < word.length() ; i++ ){
            char c = word.charAt(i);
            //System.out.println(c);

            if(hashMap.containsKey(c)){
                hashMap.put(c , hashMap.get(c) +1);
                //System.out.println(hashMap);
            }else {
                hashMap.put(c,1);

            }
        }
        System.out.println(hashMap);



       /* HashMap<String, Integer> hashMap = new HashMap<>();
        // Key-Value değerini ekle
        hashMap.put("A", 1);
        hashMap.put("B", 2);
        hashMap.put("C", 3);
        System.out.println("HashMap: " + hashMap);*/



    }
}