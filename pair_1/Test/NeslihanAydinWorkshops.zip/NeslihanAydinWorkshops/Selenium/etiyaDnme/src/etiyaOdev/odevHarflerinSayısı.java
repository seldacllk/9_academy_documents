package etiyaOdev;
public class odevHarflerinSayısı {
    ///*2-soru Sesli Harflerin Sayısı
    //  Bir cümledeki toplam sesli harf sayısını hesaplayan bir algoritma oluşturun. Örneğin, "Merhaba dünya" cümlesinde sesli harf sayısı 6'dır.

    public static void main(String[] args) {
        // Örnek cümleyi tanımlayalım
        String cumle = "Merhaba dünya";

        // Sesli harf sayısını hesaplayan fonksiyonu çağır
        int toplamSesliHarfSayisi = sesliHarfSayisiBul(cumle);

        // Sonucu ekrana yazdır
        System.out.println("Cümledeki toplam sesli harf sayısı: " + toplamSesliHarfSayisi);
    }

    // Cümledeki toplam sesli harf sayısını bulan fonksiyon
    public static int sesliHarfSayisiBul(String cumle) {
        // Türkçe'de kullanılan tüm sesli harfleri tanımlayalım
        String sesliHarfler = "aeiouAEIOUöÖüÜıİ";

        // Sesli harf sayacını başlat
        int sayac = 0;

        // Cümledeki her bir harfi kontrol et
        for (int i = 0; i < cumle.length(); i++) {
            // Cümlenin i. karakterini al
            char harf = cumle.charAt(i);

            // Eğer bu harf sesli harfler listesinde yer alıyorsa, sayacı artır
            if (sesliHarfler.indexOf(harf) != -1) {
                sayac++;
            }
        }

        // Toplam sesli harf sayısını döndür
        return sayac;
    }
}


