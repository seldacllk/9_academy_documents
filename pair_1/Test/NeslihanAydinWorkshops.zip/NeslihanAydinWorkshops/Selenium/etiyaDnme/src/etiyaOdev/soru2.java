package etiyaOdev;

public class soru2 {

    public static void main(String[] args) {

        ///*2-soru Sesli Harflerin Sayısı
        //  Bir cümledeki toplam sesli harf sayısını hesaplayan bir algoritma oluşturun. Örneğin, "Merhaba dünya" cümlesinde sesli harf sayısı 6'dır.

        String sentence = "merhaba dunya";
        int toplam = 0 ;
        for (int i = 0; i < sentence.length(); i++) {
            char harf = sentence.charAt(i);
            switch (harf){
                case 'a':
                case 'e':
                case 'ı':
                case 'i':
                case 'o':
                case 'ö':
                case 'u':
                case 'ü':
                    toplam++;
                    break;
                default:
                    break;

            }
        }
        System.out.println("Toplam sesli harf sayısı: " + toplam);
    }
}
