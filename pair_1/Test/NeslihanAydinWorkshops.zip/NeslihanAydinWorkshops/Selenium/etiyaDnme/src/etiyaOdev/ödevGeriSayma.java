package etiyaOdev;

public class ödevGeriSayma {
     /*
  1-soru  Sıra Geri Sayma
          Bir cümledeki kelimeleri ters sırayla döndüren bir algoritma yazın. Örneğin, "merhaba dünya" cümlesi "dünya merhaba" şeklinde döndürülmelidir.

      */
     public static void main(String[] args) {
         String word = "Merhaba Dunya";
         String[] splitted = word.split(" ");
         String reverseword = "";


         for (int i=splitted.length-1; i>=0; i--){

         //    System.out.print(splitted[i]+" ");
             reverseword = reverseword + splitted[i] + " ";

         }
         System.out.println(reverseword);

     }
    }



