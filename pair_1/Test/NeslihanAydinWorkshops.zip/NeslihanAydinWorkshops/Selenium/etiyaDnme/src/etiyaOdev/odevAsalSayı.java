package etiyaOdev;

public class odevAsalSayı {

    // Asal Sayı
    //         Verilen bir pozitif tam sayı n için n'inci asal sayıyı bulan bir algoritma yazın. Örneğin, n = 5 için çıktı 11 olmalıdır.


    public static void main(String[] args) {
        // Örnek olarak n = 5 değerini tanımlayalım
        int n = 5;

        // n'inci asal sayıyı bulmak için fonksiyonu çağır
        int sonuc = nInciAsalSayi(n);

        // Sonucu ekrana yazdır
        System.out.println(n + ". asal sayı: " + sonuc);
    }

    // n'inci asal sayıyı bulan fonksiyon
    public static int nInciAsalSayi(int n) {
        int sayac = 0; // Kaçıncı asal sayıya ulaşıldığını tutan sayaç
        int sayi = 2;  // Asal sayıları kontrol etmek için başlangıç sayısı

        while (sayac < n) {
            // Eğer sayı asal ise sayacı 1 artır
            if (asalMi(sayi)) {
                sayac++;
            }
            // Eğer n'inci asal sayıya ulaşılmamışsa, sayıyı bir artır
            if (sayac < n) {
                sayi++;
            }
        }
        return sayi; // n'inci asal sayıyı döndür
    }

    // Bir sayının asal olup olmadığını kontrol eden fonksiyon
    public static boolean asalMi(int sayi) {
        // 2'den küçük sayılar asal değildir
        if (sayi < 2) {
            return false;
        }
        // Sayının kareköküne kadar olan sayıları kontrol et
        for (int i = 2; i <= Math.sqrt(sayi); i++) {
            // Eğer sayı herhangi bir sayıya bölünüyorsa asal değildir
            if (sayi % i == 0) {
                return false;
            }
        }
        return true; // Hiçbir bölen bulunamazsa sayı asaldır

    }
}


