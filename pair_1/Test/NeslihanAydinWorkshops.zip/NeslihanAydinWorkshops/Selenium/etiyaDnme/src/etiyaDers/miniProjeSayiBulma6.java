package etiyaDers;

public class miniProjeSayiBulma6 {



    ///CALISSSSSSSS!!!!!!!!!!
    public static void main(String[] args) {

        int[] sayilar = new int[]{1, 2, 5, 7, 9, 0};
        int aranacak = 6;
        boolean varMi = false;

        for (int sayı : sayilar) {
            if (sayı == aranacak) {
                varMi = true;
                break;

            }
        }

        if (varMi) {
            System.out.println("sayı mevcuttur");

        } else {
            System.out.println("sayı mrvcut değildir");
        }


    }

}

