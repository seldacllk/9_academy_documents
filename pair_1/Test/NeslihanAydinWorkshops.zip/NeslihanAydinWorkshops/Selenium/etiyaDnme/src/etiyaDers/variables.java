package etiyaDers;

public class variables {
    public static void main(String[]args){


        System.out.println("merhaba vcs");


        int ögrenciSayım =12;
        System.out.println("ögrenci sayım :" + ögrenciSayım);
        System.out.println("ögrenci sayım :" + ögrenciSayım);
        System.out.println("ögrenci sayım :" + ögrenciSayım);


        System.out.println("ögrenci sayım :10");
        System.out.println("ögrenci sayım :10");
        System.out.println("ögrenci sayım :10");



    }
}
