package etiyaDers;

public class multiDimensionalArrayDemo1 {
    public static void main(String[] args) {
        //String sehirler --------(bu şekilde tamınlarsam bu bir string oluyor!
        //String sehirler[]-------(bu sekilde tanımlarsam bu bir arrays oluyor(tek satırdan)!
        //String sehirler[][]------(bu sekilde tanımlarsam aynı zamanda bir arrays oluyor ve birçok satırdan olusabiliryor!(satırları biz belirleyebiliriz istediğimiz kadar arrays ekleyebiliriz)

        String[][] sehirler = new String[3][3];

        sehirler[0][0] = "istanbul";
        sehirler[0][1] = "bursa";
        sehirler[0][2] = "bilecik";
        sehirler[1][0] = "ankara";
        sehirler[1] [1] = "konya";
        sehirler[1][2] = "kayseri";
        sehirler[2][0] = "diyarbakır";
        sehirler[2][1] = "sanlıurfa";
        sehirler[2][2] = "gaziantep";

        // satırları gezerken sütünlarıda gezsin istiyorsak bu da karsımıza nestedloop denilen içiçe döngüleri getiriyor. ( cok kullanılmıyor)

        for (int i = 0; i <=2; i++) {
            System.out.println("----------------------------");
            for (int j = 0; j <2 ; j++) {
                System.out.println(sehirler[i][j]);
            }
        }



    }
}
