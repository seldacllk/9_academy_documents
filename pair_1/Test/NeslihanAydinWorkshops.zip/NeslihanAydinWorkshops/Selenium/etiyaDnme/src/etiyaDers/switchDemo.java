package etiyaDers;

public class switchDemo {
    public static void main(String[] args) {
        char grade = 'A';

        switch (grade){
            case 'A':
                System.out.println("mükemmel: Gectiniz");
                break;
            case 'B':
                System.out.println("cok guzel : Gectınız");
            case 'C':
                System.out.println("iyi : gectiniz");
                break;
            case 'D':
                System.out.println("fena değil : gectınız");
                break;

            case 'F':
                System.out.println("malesef kaldınız");
                break;

            default:
                System.out.println("gecersiz not girdiniz");
        }
    }
}
