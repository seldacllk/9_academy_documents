package etiyaDers;

public class conditionals {
    public static void main(String[] args) {
        int sayı = 10;
        if (sayı<20) {

            System.out.println("Sayı 20 den küçüktür");

        }if (sayı<11){
            System.out.println("sayı 20den kucukur");

        }else {
            System.out.println("sayı 20den kucuuuk degildir");}



    }
}
