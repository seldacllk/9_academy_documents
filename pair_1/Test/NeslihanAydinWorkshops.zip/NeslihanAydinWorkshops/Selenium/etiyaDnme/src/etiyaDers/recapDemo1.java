package etiyaDers;

public class recapDemo1 {
    public static void main(String[] args) {

        int sayı1 =80;
        int sayı2= 90;
        int sayı3= 30;
        int enBüyük= sayı1;

        if (enBüyük<sayı2){

            enBüyük=sayı2;
        }
        if (enBüyük< sayı3){
            enBüyük=sayı3;
        }
        System.out.println("En büyük = "+ enBüyük);

    }

}
