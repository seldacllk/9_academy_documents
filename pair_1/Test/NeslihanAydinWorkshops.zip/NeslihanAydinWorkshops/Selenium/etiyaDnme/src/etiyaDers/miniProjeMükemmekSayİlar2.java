package etiyaDers;

public class miniProjeMükemmekSayİlar2 {

    //Mükemmel sayı nedir? ------>  kendinden başka pozitif tüm tam bölenlerin sayısı kendisine esit olan sayıya mükemmel sayı deniyor.
    // 6 matematiğe göre mükemmel sayıdır 1e bölünür 2ye bölünür ve 3 e bölünür.hepsını topladımızda da 6 eder.
    //28 bir diğer mükemmel sayıdır.1,2,4,7,14

    //şimdi bir sayının bir mükemmle sayı olup olmadıgını bulalım.

    public static void main(String[] args) {
        int number = 6;
        int total = 0;

        for (int i = 1; i <number ; i++) {
            if (number%i==0){
                total = total + i;}
            }

            if (total== number){
                System.out.println("mukemmel sayıdır");

            }else {
                System.out.println("mükemmel sayı degildir");
            }
        }

    }

///// CALISSSSSSSSSSSSS!!!!! HATA VERİYOR!!!!!!