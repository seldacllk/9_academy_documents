package etiyaDers;

public class datatypes {

    public static void main(String[] args) {
        int sayı = 12;
        sayı = 1111111;

    }
}
