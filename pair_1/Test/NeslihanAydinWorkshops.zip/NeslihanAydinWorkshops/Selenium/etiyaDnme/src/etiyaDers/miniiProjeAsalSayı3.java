package etiyaDers;

public class miniiProjeAsalSayı3 {

    public static void main(String[] args) {
        int number = 25;  // 25 sayısının asal olup olmadıgını bulacagız.
        int remainder = number % 2; //remaınder kalan mod 2/  25in 2ye bölümünden kalan 1
        System.out.println(remainder);


        boolean isprime = true;//isprime asal sayı mı demek
        for (int i = 2; i < number; i++)

            /////YARIMMMM TEKRAR CALIS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



            if(number<1)
        {
            System.out.println("gecersiz sayı");


        }
        if (number % 2 == 0) {
                isprime = false;


            }
        if (isprime){
            System.out.println("sayı asaldır");
        }else {
            System.out.println("sayı asal değildir");
        }

        }
    }