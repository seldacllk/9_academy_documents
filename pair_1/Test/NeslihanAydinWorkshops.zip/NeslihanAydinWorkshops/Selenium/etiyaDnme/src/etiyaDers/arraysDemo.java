package etiyaDers;

public class arraysDemo {

    public static void main(String[] args) {
        String ogrenci1="kutluhan";
        String ogrenci2="neslihan";
        String ogrenci3="mutluhan";
        String ogrenci4="aile";

        System.out.println(ogrenci1);
        System.out.println(ogrenci2);
        System.out.println(ogrenci3);
        System.out.println(ogrenci4);

        System.out.println("----------------------------");

        String[] ogrenciler = new String[3];
        ogrenciler[0]="kutluhan";
        ogrenciler[1]="neslihan";
        ogrenciler[2]="mutluhan";  // bu kısımda sayı arttırıp sonra ogrenci ekleyerek tekrar tekrar kod olusturmama gerek kalmıyor


        for (int i = 0; i < ogrenciler.length; i++) {
            System.out.println(ogrenciler[i]);

        }

    }
}
