package etiyaDers;

public class recapDemo2 {
    public static void main(String[] args) {
        //  double[] mylist = new double[4];    BUNUN BİR DİĞER YÖNTEMİ DAHA VAR! 6. satır ve 5. satır arasında bir fark yok!
        double[] myList = {1, 2, 3, 4, 5, 6,};
        double total = 0;
        double max = myList[0];
        for (double number : myList) {
            if (max < number) {
                max = number;
            }
            total = total + number;
            System.out.println(number);
        }
        System.out.println("toplam=" + total);
        System.out.println("en büyük=" + max);
    }

}
