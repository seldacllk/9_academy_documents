package etiyaDers;

public class methods2 {

    public static void main(String[] args) {
        String mesaj = "bugun hava cok guzel";
       // String yenimesaj = mesaj.substring(0,2);     //substring yeni birsey oluşturdu ve bize onu sonuc olarak veriyor ama void bize bir değer vermez!
        String yenimesaj=sehirver();
        System.out.println(yenimesaj);               //substring bir değer döndürüyor.
        int sayı = topla(2,7);
    }
    public static void ekle(){
        System.out.println("eklendi");
    }

    public static void sil(){
        System.out.println("silindi");
    }

    public static void guncelle(){
        System.out.println("guncellendi");

    }

    public static int topla(int sayı1, int sayı2){  //void yerine ıny koyduk... bu foksiyon integer turunde bir deger döndurur demek
        //return 5;
        return sayı1+sayı2;
    }

    public static String sehirver(){
        return "ankara";
    }
}
