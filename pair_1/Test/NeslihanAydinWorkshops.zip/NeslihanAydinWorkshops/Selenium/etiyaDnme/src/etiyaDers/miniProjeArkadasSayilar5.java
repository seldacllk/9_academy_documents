package etiyaDers;
public class miniProjeArkadasSayilar5 {

    /*

     220-284  kendileri hariç pozitif tam bölenleri birbirine toplamı bribirbine eşit sayılara
    arkadaş sayı deniyor. yani 1den basşlayıp 220 ye kadar 220yi
            (220 dhil değil)tüm sayıların toplamı 284 iken  1den başlayıp 284 kadar(284 dahil değil) tüm sayıların toplamı
        220 ye esit ise bu iki sayı () -> arkadaştır
    *\

     */
    public static void main(String[] args) {

        int sayı1 = 220;
        int sayı2 =284;
        int toplam1 = 0;
        int toplam2 = 0;

        for (int i = 1; i <sayı1; i++) {
            if (sayı1 % i == 0) {
                toplam1 = toplam1 + i;

            }
        }


            for (int i =1 ; i <sayı2; i++) {
                if (sayı2 % i == 0) {
                    toplam2 = toplam2 + i;

                }
            }
        if(sayı1==toplam2  || sayı2 == toplam1) {

            System.out.println(" bu iki sayı arkadaştır");
        }else{
                System.out.println("bu iki sayı arkadaş değil");
            }

        }

    }

