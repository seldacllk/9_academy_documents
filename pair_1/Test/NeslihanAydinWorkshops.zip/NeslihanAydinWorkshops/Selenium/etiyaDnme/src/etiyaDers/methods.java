package etiyaDers;

public class methods {
    public static void main(String[] args) {
        //fonksiyon yazarak kendimizi tekrarlamayı engellemiş oluyoruz.
        /*
        main methodu yazdık ve süslü parantezin dısına bir psvm daha koyuyoruz ama main kısmına bir

        ornek: publıc static void sayıBulmaca(){---------->  gibiii....
         */
    }
}
