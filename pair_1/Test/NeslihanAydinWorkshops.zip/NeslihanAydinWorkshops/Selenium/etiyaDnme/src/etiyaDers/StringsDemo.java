package etiyaDers;

import java.util.Locale;

public class StringsDemo {
    public static void main(String[] args) {
        String mesaj = "bugun hava cok guzel.";

        System.out.println("eleman sayısı:" + mesaj.length());// Uzunlugu ölçer kaö harf var diye...
        System.out.println("5.eleman: " + mesaj.charAt(4));  // kelimedeki hangi harf kararkterini istiyorsak...
        System.out.println(mesaj.concat(" Yasasın!")); // BİRLEŞİTİRİR! yeni bir string oluşturur.
        System.out.println(mesaj); //tek yazar çünkü concat kullanamalı.kullanırsa yeni bir string oluşturur...
        System.out.println(mesaj.startsWith("b"));// b ıle başlıyorsa true dondur.
        System.out.println(mesaj.endsWith("ç"));  // hangi harfle bittigini soruyorum. unutma! java küçük büyük harf duryarlıdır. büyük sorgularsaydım yine falce alırdımSystem.out.println(ME);
        char[] karakterler = new char[5];
        mesaj.getChars(0, 4, karakterler, 0);//0 basla 4te bitir.yani bana karakterleri ve o zaman char array...
        System.out.println(karakterler);//yukarıda getcharsla true false donuyor biz birde bunları yazdır dersek o  zaman o istenilen karakterleri yazdırır.
        System.out.println(mesaj.indexOf('a'));// boyle yazarsak istenilen karaterin kaçıncı sırada oldugu yazar.ama ilk buldugu a harfini verir.sonrakilere bakmaz.
        System.out.println(mesaj.lastIndexOf("av"));// tırnaklara dikkat et dene! buldugu ııcın yıne bakmadı.
        System.out.println(mesaj.lastIndexOf("a")); // buda sagdan saymaya başlar yukarıdakının tam tersi!

        //System.out.println(mesaj.replace(' ','-'));// ilgili metnimizdeki degerleri deiştirebilriz.örn: ingilizce karakterlerin türkçeye cevrilmesi gibi ya da karakterler arasında bosluk bırkmak gibi..
        String yeniMesaj = mesaj.replace(' ', '-');
        System.out.println(yeniMesaj);
        System.out.println(mesaj.substring(2));// 2den itibaren yaz demek! yani bugun degil gun diye alıyor...yani 2 indexinden itibaren parçala diyoruz.
        System.out.println(mesaj.substring(2, 4)); //boyle yazınca 2den al 4 kadar yazar...bugun değilde ug yazar...


        for (String kelime : mesaj.split(" ")) // boşluları kesip altalata sıralıyor. örnek yapppp!
            System.out.println(mesaj.toLowerCase());// Büyük yapar.
        System.out.println(mesaj.trim()); //basındakı ve sonundakı boslukları siler.


        {}

        String mesaj2= "Hiç";
        System.out.println(mesaj2.concat(mesaj));
        System.out.println(mesaj2.charAt(0));
        System.out.println(mesaj2.length());
        System.out.println(mesaj2.toLowerCase(Locale.ROOT));  //buraya bir deger mi girecek
        System.out.println(mesaj2.toLowerCase());
        System.out.println(mesaj2.toUpperCase());
        System.out.println(mesaj2.startsWith("H")); // H harfi ile başıyorsa true döndürür. dstring içinde baslamayan harfle baslarsa false dönürür.
        System.out.println(mesaj2.endsWith("ç"));  // hangi harfle bittigini soruyorum. unutma! java küçük büyük harf duryarlıdır. büyük sorgularsaydım yine falce alırdımSystem.out.println(ME);

    }
}
