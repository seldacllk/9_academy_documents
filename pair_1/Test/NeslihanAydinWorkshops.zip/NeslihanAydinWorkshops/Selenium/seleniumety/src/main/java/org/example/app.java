package org.example;

import org.openqa.selenium.firefox.FirefoxDriver;

public class app {
    public static void main(String[] args) {
    FirefoxDriver driver = new FirefoxDriver();
        driver.get("https://google.com");
        driver.quit();

        //BİR İNSANIN TARAYICI...
        //
        //

        FirefoxDriver firefoxDriver = new FirefoxDriver();

        firefoxDriver.get("https://www.saucedemo.com/");





}
}


