Her dersin sonundaki etkinlik buraya kayıt ediliyor.
